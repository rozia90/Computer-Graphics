//lab11_sol.c
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include"GL/glut.h"

//global constants
#define ANIMATION_DELAY 20
#define PI 3.14

//function declerations
void drawingCB(void);
void reshapeCB(int width, int height);
void keyboardCB(unsigned char key, int x, int y);
void keyboardSpecialCB(int key, int x, int y);
void TimerCB(int value);
GLubyte *readBMP(char *imagepath, int *width, int *height);
GLuint generateTextures(char *imagepath);
void TerminationErrorFunc(char *ErrorString);


//globals
float earthRotateAngle = 0;
float sunRotateAngle = 0;
float moonRotateAngle = 0;
int ViewPointAngle1 = 0, ViewPointAngle2 = 0;
int FOVy = 80;
int OnOff = 1;
float rotateFactor = 0.5;
int ro = 0;
//textures gloabals
int BoxTextureIds[6];
#define SKY_RIGHT 0
#define SKY_LEFT  1
#define SKY_UP    2
#define SKY_DOWN  3
#define SKY_BACK  4
#define SKY_FRONT 5
int TeapotTextureId;
GLuint earthTexID;
GLuint moonTexID;
GLuint sunTexID;
int light0 = 1, light1 = 1, light2 = 1;
int main(int argc, char** argv)
{

	//initizlizing GLUT
	glutInit(&argc, argv);

	//initializing window
	glutInitWindowSize(1000, 1000);
	glutInitWindowPosition(100, 50);
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
	glutCreateWindow("3D world");

	//enable depth testing
	glEnable(GL_DEPTH_TEST);

	//registering callbacks
	glutDisplayFunc(drawingCB);
	glutReshapeFunc(reshapeCB);
	glutKeyboardFunc(keyboardCB);
	glutSpecialFunc(keyboardSpecialCB);
	glutTimerFunc(ANIMATION_DELAY, TimerCB, 0);

	//specify textures and setting Specific texture parameters
	BoxTextureIds[SKY_RIGHT] = generateTextures("posx.bmp");
	BoxTextureIds[SKY_LEFT] = generateTextures("negx.bmp");
	BoxTextureIds[SKY_UP] = generateTextures("posy.bmp");
	BoxTextureIds[SKY_DOWN] = generateTextures("negy.bmp");
	BoxTextureIds[SKY_BACK] = generateTextures("posz.bmp");
	BoxTextureIds[SKY_FRONT] = generateTextures("negz.bmp");
	earthTexID = generateTextures("earth.bmp");
	sunTexID = generateTextures("sun.bmp");
	moonTexID = generateTextures("moon.bmp");

	//setting Global texture parameters
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); //determine how texture mapping interacts   														//with shading modes. Can be: GL_MODULATE or GL_BLEND or GL_REPLACE 
	glEnable(GL_TEXTURE_2D);

	//starting main loop
	glutMainLoop();
}


GLuint generateTextures(char *imagepath)
{
	GLubyte *ImageData;
	int width, height;
	GLuint TextureID;

	//reading the image
	ImageData = readBMP(imagepath, &width, &height);

	//Giving a texture ID
	glGenTextures(1, &TextureID);
	glBindTexture(GL_TEXTURE_2D, TextureID);

	//Assign Image as a texture 
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, ImageData);

	//freeing image memory
	free(ImageData);

	//setting Specific texture parameters 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); // GL_REPEAT or GL_CLAMP
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // GL_LINEAR or GL_NEAREST
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	return TextureID;
}




void drawingCB(void)
{
	GLenum er;
	double D = 10;
	double d = 0.02;
	double R = 5;
	GLUquadricObj* pObj;

	GLfloat light_1_diffuse[] = { 2, 2, 2, 1 };
	GLfloat light_1_position[] = { 0, 0, 0, 1 };

	//clearing the background
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//initializing modelview transformation matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//setting viewing angle
	gluLookAt(R*cos((double)ViewPointAngle1*PI / 180), R*sin((double)ViewPointAngle2*PI / 180), R*sin((double)ViewPointAngle1*PI / 180), 0, 0, 0, 0,1, 0);

	//drawing a box
	//right
    glBindTexture(GL_TEXTURE_2D,BoxTextureIds[SKY_RIGHT]);
	glBegin(GL_QUADS);
	glTexCoord2f(0,0); glVertex3f(+D-d,-D,-D);
	glTexCoord2f(1,0); glVertex3f(+D-d,-D,+D);
	glTexCoord2f(1,1); glVertex3f(+D-d,+D,+D);
	glTexCoord2f(0,1); glVertex3f(+D-d,+D,-D);
	glEnd();
	//left
    glBindTexture(GL_TEXTURE_2D,BoxTextureIds[SKY_LEFT]);
	glBegin(GL_QUADS);
	glTexCoord2f(0,0); glVertex3f(-D+d,-D,+D);
	glTexCoord2f(1,0); glVertex3f(-D+d,-D,-D);
	glTexCoord2f(1,1); glVertex3f(-D+d,+D,-D);
	glTexCoord2f(0,1); glVertex3f(-D+d,+D,+D);
	glEnd();
	//up
    glBindTexture(GL_TEXTURE_2D,BoxTextureIds[SKY_UP]);
	glBegin(GL_QUADS);
	glTexCoord2f(0,0); glVertex3f(-D,+D-d,-D);
	glTexCoord2f(1,0); glVertex3f(+D,+D-d,-D);
	glTexCoord2f(1,1); glVertex3f(+D,+D-d,+D);
	glTexCoord2f(0,1); glVertex3f(-D,+D-d,+D);
	glEnd();
	//down
    glBindTexture(GL_TEXTURE_2D,BoxTextureIds[SKY_DOWN]);
	glBegin(GL_QUADS);
	glTexCoord2f(0,0); glVertex3f(-D,-D+d,+D);
	glTexCoord2f(1,0); glVertex3f(+D,-D+d,+D);
	glTexCoord2f(1,1); glVertex3f(+D,-D+d,-D);
	glTexCoord2f(0,1); glVertex3f(-D,-D+d,-D);
	glEnd();
	//back
    glBindTexture(GL_TEXTURE_2D,BoxTextureIds[SKY_BACK]);
	glBegin(GL_QUADS);
	glTexCoord2f(0,0); glVertex3f(-D,-D,-D+d);
	glTexCoord2f(1,0); glVertex3f(+D,-D,-D+d);
	glTexCoord2f(1,1); glVertex3f(+D,+D,-D+d);
	glTexCoord2f(0,1); glVertex3f(-D,+D,-D+d);
	glEnd();
	//front
    glBindTexture(GL_TEXTURE_2D,BoxTextureIds[SKY_FRONT]);
	glBegin(GL_QUADS);
	glTexCoord2f(0,0); glVertex3f(+D,-D,+D-d);
	glTexCoord2f(1,0); glVertex3f(-D,-D,+D-d);
	glTexCoord2f(1,1); glVertex3f(-D,+D,+D-d);
	glTexCoord2f(0,1); glVertex3f(+D,+D,+D-d);
	glEnd();


	if (OnOff)
	{
		//lights on
		glLightfv(GL_LIGHT1, GL_DIFFUSE, light_1_diffuse);
		glLightfv(GL_LIGHT1, GL_POSITION, light_1_position);
		//drawing sun
		glRotated((GLdouble)sunRotateAngle, 0.0, 1.0, 0.0);
		glRotated(90, -1.0, 0.0, 0.0);
		printf("ObjectRotatingAngle:%d, Viewing points angles: %d,%d\n", sunRotateAngle, ViewPointAngle1, ViewPointAngle2);
		glBindTexture(GL_TEXTURE_2D, sunTexID);
		pObj = gluNewQuadric();
		gluQuadricTexture(pObj, GL_TRUE);
		gluSphere(pObj, 0.5, 100, 100);
		gluDeleteQuadric(pObj);
		glRotated(90, 1.0, 0.0, 0.0);

		//drawing earth
		glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT1);
		glTranslated(3,0,0);
		glRotated((GLdouble)earthRotateAngle, 0.0, 1.0, 0.0);
		glRotated(90, -1.0,0.0,0.0);
		printf("ObjectRotatingAngle:%d, Viewing points angles: %d,%d\n", earthRotateAngle, ViewPointAngle1, ViewPointAngle2);
		glBindTexture(GL_TEXTURE_2D, earthTexID);
		pObj = gluNewQuadric();
		gluQuadricTexture(pObj, GL_TRUE);
		gluSphere(pObj, 0.2, 100, 100);
		gluDeleteQuadric(pObj);

		//drawing moon
		glTranslated(0.6, 0,00);
		glRotated((GLdouble)moonRotateAngle, 1.0, 1.0, 0.0);
		printf("ObjectRotatingAngle:%d, Viewing points angles: %d,%d\n", moonRotateAngle, ViewPointAngle1, ViewPointAngle2);
		glBindTexture(GL_TEXTURE_2D, moonTexID);
		pObj = gluNewQuadric();
		gluQuadricTexture(pObj, GL_TRUE);
		gluSphere(pObj, 0.1, 100, 100);
		gluDeleteQuadric(pObj);
		//lights off
		glDisable(GL_LIGHTING);
		glDisable(GL_LIGHT1);
		
	}


	//swapping buffers and displaying
	glutSwapBuffers();

	//check for errors
	er = glGetError();  //get errors. 0 for no error, find the error codes in: https://www.opengl.org/wiki/OpenGL_Error
	if (er) printf("error: %d\n", er);
}



void reshapeCB(int width, int height)
{
	float zNear, zFar;

	//define our ortho
	zNear = 1; zFar = 40;

	//update viewport
	glViewport(0, 0, width, height);

	//clear the transformation matrices (load identity)
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	//projection
	gluPerspective(FOVy, 1, zNear, zFar);
}


void keyboardCB(unsigned char key, int x, int y) {
	switch (key) {
	case 27:
		exit(0);
		break;
	case '+':
		FOVy = FOVy - 1;
		reshapeCB(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
		glutPostRedisplay();
		break;
	case '-':
		FOVy = FOVy + 1;
		reshapeCB(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
		glutPostRedisplay();
		break;
	case ' ':
		OnOff = !OnOff;
		break;
	}
}


void keyboardSpecialCB(int key, int x, int y)
{
	switch (key) {
	case GLUT_KEY_UP:
		rotateFactor+=0.1;
		glutPostRedisplay();
		break;
	case GLUT_KEY_DOWN:
		if(rotateFactor>=0.1)
		rotateFactor-=0.1;
		glutPostRedisplay();
		break;
	}
}

void TimerCB(int value)
{
	sunRotateAngle = (sunRotateAngle + rotateFactor) ;
	earthRotateAngle = (earthRotateAngle +(rotateFactor*10));
	moonRotateAngle = (moonRotateAngle) ;

	// reassign to the timer event again		
	glutTimerFunc(ANIMATION_DELAY, TimerCB, value);

	// call redisplay 	
	glutPostRedisplay();
}

// Function to load bmp file
// buffer for the image is allocated in this function, you should free this buffer
GLubyte *readBMP(char *imagepath, int *width, int *height)
{
	unsigned char header[54]; // Each BMP file begins by a 54-bytes header
	unsigned int dataPos;     // Position in the file where the actual data begins
	unsigned int imageSize;   // = width*height*3
	unsigned char * data;
	unsigned char tmp;
	int i;

	// Open the file
	FILE * file = fopen(imagepath, "rb");
	if (!file) {
		TerminationErrorFunc("Image could not be opened\n");
	}

	if (fread(header, 1, 54, file) != 54) { // If not 54 bytes read : problem
		TerminationErrorFunc("Not a correct BMP file\n");
	}

	if (header[0] != 'B' || header[1] != 'M') {
		TerminationErrorFunc("Not a correct BMP file\n");
	}

	// Read ints from the byte array
	dataPos = *(int*)&(header[0x0A]);
	imageSize = *(int*)&(header[0x22]);
	*width = *(int*)&(header[0x12]);
	*height = *(int*)&(header[0x16]);

	// Some BMP files are misformatted, guess missing information
	if (imageSize == 0)
		imageSize = *width**height * 3; // 3 : one byte for each Red, Green and Blue component
	if (dataPos == 0)
		dataPos = 54; // The BMP header is done that way

					  // Create a buffer
	data = malloc(imageSize * sizeof(GLubyte));

	// Read the actual data from the file into the buffer
	fread(data, 1, imageSize, file);


	//swap the r and b values to get RGB (bitmap is BGR)
	for (i = 0; i<*width**height; i++)
	{
		tmp = data[i * 3];
		data[i * 3] = data[i * 3 + 2];
		data[i * 3 + 2] = tmp;
	}


	//Everything is in memory now, the file can be closed
	fclose(file);

	return data;
}



void TerminationErrorFunc(char *ErrorString)
{
	char string[256];
	printf(ErrorString);
	fgets(string, 256, stdin);     // warning: unsafe (see fgets instead)

	exit(0);
}

