#include<stdio.h>
#include<math.h>
#include"GL/glut.h" // why do we need this line ?

#define Pi 3.141592654
#define MAX_POINTS 36 // how can you increase the density of the points ?

typedef struct POINT{
	GLfloat x;
	GLfloat y;
} Point;

void function1(float VecDeg, float VecSize, Point *p);
float function2(float a); 

void RenderCallBack(void);

Point points[MAX_POINTS];

void main(int argc, char** argv)
{
	int n;
	for(n=0 ; n<MAX_POINTS ; n++){
		function1( (n+1)*10, 0.8 ,&points[n]);
	}

	glutInit(&argc,argv);
	glutInitWindowPosition(20,20);
	glutInitWindowSize(200,200);
	glutInitDisplayMode(GLUT_RGBA);

	glutCreateWindow("Clock");
	glutDisplayFunc(RenderCallBack);

	glutMainLoop(); 
}

void function1(float VecDeg, float VecSize, Point *p) // which name would be more appropriate for this function ?
{
	p->x = (GLfloat) sin(function2(VecDeg)) * VecSize;
	p->y = (GLfloat) cos(function2(VecDeg)) * VecSize;
}

float function2(float a) // which name would be more appropriate for this function ?
{
	return a*Pi/180.0;
}

void RenderCallBack() // what is the purpose of this function ?
{
	int n;
	GLenum er;

	glClearColor(0.5f,0.5f,0.5f,1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(1.0f,1.0f,0.0);
	glBegin(GL_POINTS);
	for(n=0 ; n<MAX_POINTS ; n++){
		glVertex2f(points[n].x,points[n].y);
	}
	glEnd();

	glFlush();

	er = glGetError();
}
