//lab02.c
#include<stdio.h>
#include<math.h>
#include"GL/glut.h" 


#define Pi 3.141592654

//vertex array
typedef struct POINT {
	GLfloat x;
	GLfloat y;
} Point;
#define EYE_VERTEX_NUM 36 
#define LIPS_VERTEX_NUM 360 
#define HAIR_VERTEX_NUM 18
#define flower_VERTEX_NUM 100
Point eye_vertexes[EYE_VERTEX_NUM];
Point lips_vertexes[LIPS_VERTEX_NUM];
Point Hair1_vertexes[HAIR_VERTEX_NUM];
Point Hair2_vertexes[HAIR_VERTEX_NUM];
Point flower_vertexes[flower_VERTEX_NUM];

//function declerations
void Deg2Vector(float VecDeg, float VecSize, Point *p);
float Deg2Rad(float deg);
void drawingCB(void);
void reshapeCB(int width, int height);
void drawLips();
void drawEye();
void drawHair();
void drawFlower(float x, float y);

int main(int argc, char *argv[])
{
	//initializing points and circle array
	int n;
	//eye
	for (n = 0; n<EYE_VERTEX_NUM; n++) {
		Deg2Vector((n + 1) * 360 / EYE_VERTEX_NUM, 0.1, &eye_vertexes[n]);
	}
	//lips
	for (n = 0; n<LIPS_VERTEX_NUM; n++) {
		Deg2Vector((n + 1) * 180 / LIPS_VERTEX_NUM, 0.9, &lips_vertexes[n]);
	}
	//hair
	for (n = 0; n<HAIR_VERTEX_NUM; n++) {
		Deg2Vector((n + 1) * 180 / HAIR_VERTEX_NUM, 0.7, &Hair1_vertexes[n]);
	}
	for (n = 0; n<HAIR_VERTEX_NUM; n++) {
		Deg2Vector((n + 1) * 180 / HAIR_VERTEX_NUM, 0.9, &Hair2_vertexes[n]);
	}
	for (n = 0; n<flower_VERTEX_NUM; n++) {
		Deg2Vector((n + 1) * 360 / flower_VERTEX_NUM, 0.2, &flower_vertexes[n]);
	}
	//initizlizing GLUT
	glutInit(&argc, argv);

	//initializing window
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(500, 500);
	glutInitDisplayMode(GLUT_RGB);
	glutCreateWindow("flowers and face");

	//registering callbacks
	glutDisplayFunc(drawingCB);
	glutReshapeFunc(reshapeCB);
	//starting main loop
	glutMainLoop();
}

// create vector from angle and size of vector
void Deg2Vector(float VecDeg, float VecSize, Point *p)
{
	p->x = (GLfloat)sin(Deg2Rad(VecDeg + 90)) * VecSize;
	p->y = (GLfloat)cos(Deg2Rad(VecDeg + 90)) * VecSize;
}

// convert degree to radians
float Deg2Rad(float deg)
{
	return deg*Pi / 180.0;
}

// rendering callback
void drawingCB()
{
	int n, i, factor = 0;
	float x, y;
	GLenum er;
	srand(time(NULL));
	glMatrixMode(GL_MODELVIEW);
	//clearing the background
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//drawing points
	glColor3f(0.1f, 0.5f, 0.1f);
	glPointSize(4);
	glLoadIdentity();
	glPushMatrix();
	glTranslatef(0, -0.3, 0);
	drawLips();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0.4, 0.1, 0);
	drawEye();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-0.4, 0.1, 0);
	drawEye();
	glPopMatrix();
	glPushMatrix();
	glScalef(0.6, -0.6, 0.6);
	glTranslatef(0, -0.3, 0);
	drawHair();
	glPopMatrix();

	for (i = 0; i < 50; i++) { //draw where x>1
		glPushMatrix();
		do {		
			x = (1.0 / ((rand() % 10) + 0))*10;
			y = (1.0 / ((rand() % 10) + 0));
			if (i % 2 == 0) y = y * 1; else y = y*-1;
		} while (x < 1);
		glTranslatef(x, y, 0);
		drawFlower(1.0 / ((rand() % 10) + 0), 1.0 / ((rand() % 10) + 0));
		glPopMatrix();
	}
	for (i = 0; i < 50; i++) {
		glPushMatrix();
		do {
			x = (1.0 / (rand() % 10)) * 10;
			y = (1.0 / (rand() % 10));
			if (i % 2 == 0) y = y * 10; else y = y*-10;
		} while (x < 1);
		glTranslatef(x, y, 0);
		drawFlower(1.0 / (rand() % 10) , 1.0 / (rand() % 10) );
		glPopMatrix();
	}
	for (i = 0; i < 50; i++) { //draw where x<-1
		glPushMatrix();
		do {
			x = (1.0 / (rand() % 10)) * -10;
			y = (1.0 / (rand() % 10));
			if (i%2==0) y=y*1; else y=y*-1;
		} while (x > -1);
		glTranslatef(x, y, 0);
		drawFlower(1.0 / (rand() % 10), 1.0 / (rand() % 10) );
		glPopMatrix();
	}

	for (i = 0; i < 50; i++) {
		glPushMatrix();
		do {
			x = (1.0 / (rand() % 10)) * -10;
			y = (1.0 / (rand() % 10) );
			if (i % 2 == 0) y = y * 10; else y = y*-10;
		} while (x > -1);
		glTranslatef(x, y, 0);
		drawFlower(1.0 / (rand() % 10), 1.0 / (rand() % 10));
		glPopMatrix();
	}
	for (i = 0; i < 50; i++) { //draw where y>1
		glPushMatrix();
		do {
			x = (1.0 / (rand() % 10) );
			y = (1.0 / (rand() % 10) )*10;
			if (i % 2 == 0) x = x * 1; else x = x*-1;
		} while (y<1);
		glTranslatef(x, y, 0);
		drawFlower(1.0 / (rand() % 10), 1.0 / (rand() % 10) );
		glPopMatrix();
	}

	for (i = 0; i < 50; i++) {
		glPushMatrix();
		do {
			x = (1.0 / (rand() % 10) );
			y = (1.0 / (rand() % 10) ) * 10;
			if (i % 2 == 0) x = x * 10; else x = x*-10;
		} while (y<1);
		glTranslatef(x, y, 0);
		drawFlower(1.0 / (rand() % 10), 1.0 / (rand() % 10));
		glPopMatrix();
	}
	for (i = 0; i < 50; i++) { //draw where y<-1
		glPushMatrix();
		do {
			x = (1.0 / (rand() % 10));
			y = (1.0 / (rand() % 10)) * -10;
			if (i % 2 == 0) x = x * 10; else x = x*-10;
		} while (y>-1);
		glTranslatef(x, y, 0);
		drawFlower(1.0 / (rand() % 10), 1.0 / (rand() % 10));
		glPopMatrix();
	}
	for (i = 0; i < 50; i++) {
		glPushMatrix();
		do {
			x = (1.0 / (rand() % 10));
			y = (1.0 / (rand() % 10)) * -10;
			if (i % 2 == 0) x = x * 1; else x = x*-1;
		} while (y>-1);
		glTranslatef(x, y, 0);
		drawFlower(1.0 / ((rand() % 10) + 0), 1.0 / ((rand() % 10) + 0));
		glPopMatrix();
	}

	//forces execution of OpenGL functions in finite time
	glFlush();

	//check for errors
	er = glGetError();  //get errors. 0 for no error, find the error codes in: https://www.opengl.org/wiki/OpenGL_Error
	if (er) printf("error: %d\n", er);
}

void drawLips() {
	int n;

	//drawing circle
	glLineWidth(2);
	glColor3f(1.0f, 0.0f, 0.0f);
	glScalef(0.4, 0.3, 0.3);
	glBegin(GL_POLYGON);
	for (n = 0; n<LIPS_VERTEX_NUM; n++) {
		glVertex2f(lips_vertexes[n].x, lips_vertexes[n].y);
	}
	glEnd();
}

void drawHair() {
	int n;

	//drawing circle
	glLineWidth(1);
	glColor3f(0.0f, 0.0f, 0.0f);

	glBegin(GL_LINES);
	for (n = 1; n<HAIR_VERTEX_NUM - 2; n++) {
		glVertex2f(Hair1_vertexes[n].x, Hair1_vertexes[n].y);
		glVertex2f(Hair2_vertexes[n].x, Hair2_vertexes[n].y);
	}
	glEnd();
}

void drawEye() {
	int n;
	glColor3f(0.0f, 0.0f, 1.0f);
	glBegin(GL_POLYGON);
	for (n = 0; n<EYE_VERTEX_NUM; n++) {
		glVertex2f(eye_vertexes[n].x, eye_vertexes[n].y);
	}
	glEnd();

}

void drawFlower(float z, float w) {
	int n, x, y;
	if (z > 0.5) { x = 1; y = 0; }
	else { x = 0; y = 1; }
	glColor3f(x, y, z);
	glBegin(GL_POLYGON);
	for (n = 0; n<flower_VERTEX_NUM; n++) {
		glVertex2f(flower_vertexes[n].x, flower_vertexes[n].y);
	}
	glEnd();
	glColor3f(y, w, x);
	glPushMatrix();
	glScalef(0.8, 0.8, 1);
	glTranslatef(0.25, 0, 0);
	glBegin(GL_POLYGON);
	for (n = 0; n<flower_VERTEX_NUM; n++) {
		glVertex2f(flower_vertexes[n].x, flower_vertexes[n].y);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();
	glScalef(0.8, 0.8, 1);
	glTranslatef(-0.25, 0, 0);
	glBegin(GL_POLYGON);
	for (n = 0; n<flower_VERTEX_NUM; n++) {
		glVertex2f(flower_vertexes[n].x, flower_vertexes[n].y);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();
	glScalef(0.8, 0.8, 1);
	glTranslatef(0, 0.25, 0);
	glBegin(GL_POLYGON);
	for (n = 0; n<flower_VERTEX_NUM; n++) {
		glVertex2f(flower_vertexes[n].x, flower_vertexes[n].y);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();
	glScalef(0.8, 0.8, 1);
	glTranslatef(0, -0.25, 0);
	glBegin(GL_POLYGON);
	for (n = 0; n<flower_VERTEX_NUM; n++) {
		glVertex2f(flower_vertexes[n].x, flower_vertexes[n].y);
	}
	glEnd();
	glPopMatrix();
}

void reshapeCB(int width, int height)
{
	float left, right, bottom, top;
	float AR;
	glMatrixMode(GL_PROJECTION);
	// define our ortho
	left = -3.5;
	right = 3.5;
	top = 3.5;
	bottom = -3.5;

	// 1)update viewport
	glViewport(0, 0, width, height);
	// 2) clear the transformation matrices (load identity)
	glLoadIdentity();
	// 3) compute the aspect ratio
	AR = width / height;
	// 4) if AR>=1 update left, right
	if (AR > 1) {
		left = left*AR;
		right = right*AR;
	}
	// 5) else i.e. AR<1 update the top, bottom
	else {
		top = top / AR;
		bottom = bottom / AR;
	}
	// 6) definnig the boundary of the model using gluOrtho2D 
	gluOrtho2D(left, right, bottom, top);
}
